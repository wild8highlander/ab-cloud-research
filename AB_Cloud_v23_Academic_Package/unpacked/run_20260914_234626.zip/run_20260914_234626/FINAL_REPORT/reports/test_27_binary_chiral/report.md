# Test 27: Binary chiral symmetry at α=1/2
Verdict: PASS   |   Generated: 2026-09-15 03:09:45   |   Suite: AB-Cloud v23 SUPERCOMBO (Julia 1.12.0)

## What this test verifies
EXACT: defect 0 on pure lattice; W>0 row is the honest breaker control. ζ-dictionary (v23.2 rework): pass 1 embeds 20,000 zeros (honest ⟨r⟩ verdict), HARDCORE embeds the full 50,000 with ±E pairing probes, ⟨r⟩ GUE-window + Poisson discrimination control, 5×10k block stationarity and KS GUE-vs-GOE classification.
 METHOD: EXACT: defect 0 on pure lattice; W>0 row is the honest breaker control. ζ-dictionary (v23.2 rework): pass 1 embeds 20,000 zeros (honest ⟨r⟩ verdict), HARDCORE embeds the full 50,000 with ±E pairing probes, ⟨r⟩ GUE-window + Poisson discrimination control, 5×10k block stationarity and KS GUE-vs-GOE classification.
Test 27 ζ-DEEP (50k): pairing exact on the 100000-dim dictionary, ⟨r⟩ 0.6119 (GUE 0.5996), Poisson control 0.3864, block spread 0.0050, KS D_GUE 0.0216 vs D_GOE 0.0881.
Test 27 HARDCORE: exact 0.00e+00, ε-row 5.77e-03 (ε_rms 0.0058), vortex 0.00e+00 (preserved), Coulomb W-scan 0.101→0.746 (ratio 7.42), ε-floor W-independent.

## Result
 Test 27b [HARDCORE pass 2]: 8 sub-checks, 0 failed → PASS

## Plots
- `plots/plot_01.png` — 1600×1000, ABPlotV23 engine (supersampled)
- `plots/plot_02.png` — 1600×1000, ABPlotV23 engine (supersampled)
- `plots/plot_03.png` — 1600×1000, ABPlotV23 engine (supersampled)
- `plots/animation.gif` — animated reveal of every plot of this test

## Independent verification guide
Reproduce with: julia ab_cloud_v23.jl --test 27 --no-two-pass
Every computation is logged in logs/computation_log.txt (timestamps + deltas); raw console output in logs/stdout_capture.txt.

## FULL COMPUTATION LOG

```text
[03:07:31.877] [+12042.906s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=0.00, torus, 0 vortices, model=:monumental
[03:07:42.466] [+12053.494s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=1.00, torus, 0 vortices, model=:monumental
[03:07:57.316] [+12068.344s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=0.00, torus, 2 vortices, model=:monumental
[03:08:09.555] [+12080.584s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=0.50, torus, 2 vortices, model=:monumental
[03:08:19.657] [+12090.685s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=1.00, torus, 2 vortices, model=:monumental
[03:08:33.394] [+12104.422s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=2.00, torus, 2 vortices, model=:monumental
[03:08:44.376] [+12115.405s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=4.00, torus, 2 vortices, model=:monumental
[03:08:58.626] [+12129.654s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=0.50, torus, 0 vortices, model=:monumental
[03:09:10.593] [+12141.621s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=1.00, torus, 0 vortices, model=:monumental
[03:09:21.957] [+12152.985s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=2.00, torus, 0 vortices, model=:monumental
[03:09:34.381] [+12165.410s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=4.00, torus, 0 vortices, model=:monumental
[03:09:43.051] [+12174.079s]  calc: KS D = 0.021619, p_asymptotic = 9.567870e-21 (n=49999, λ=4.8368)
[03:09:43.060] [+12174.089s]  calc: KS D = 0.088053, p_asymptotic = 0.000000e+00 (n=49999, λ=19.6997)
```

## CONSOLE CAPTURE

```text

════════════════════════════════════════════════════════════
TEST 27 (pass 2, HARDCORE): binary chiral symmetry — deep audit
Exact row + ε_rms contract + vortex preservation + Coulomb W-scan
(launch-standard lattice, 96x96 in two-pass mode)
────────────────────────────────────────────────────────────
 ⚠ RUNTIME: 11 builds + 11 S·H·S defect evals at 96x96 (Diagonal S, O(N²)) + ζ-50k deep statistics (O(n)) — ≈ 2–4 min
 H1 exact row (W=0, clean):     defect = 0.00e+00 < ✓ 1e-10
 H2 ε row (W=1.0, Nv=0):      defect = 5.77e-03 vs ε_rms = 0.0058 (analytic) ∈ [0.5, 2.0]× ✓
 H2v vortex row (Nv=2, W=0):    defect = 0.00e+00 < 1e-10 ✓ (bond phases PRESERVE AIII)
 W-scan (Nv=2) W=0.5: defect = 1.0052e-01
 W-scan (Nv=2) W=1.0: defect = 2.0010e-01
 W-scan (Nv=2) W=2.0: defect = 3.9425e-01
 W-scan (Nv=2) W=4.0: defect = 7.4620e-01
 H3 scan: monotone ✓, defect(W=4)/defect(W=0.5) = 7.42 ∈ [5, 12] ✓
 Nv=0 ε-floor diagnostic (residual ε is FIXED-amplitude):
 W-scan (Nv=0) W=0.5: defect = 5.7704e-03 ≈ ε_rms (W-independent ✓)
 W-scan (Nv=0) W=1.0: defect = 5.7704e-03 ≈ ε_rms (W-independent ✓)
 W-scan (Nv=0) W=2.0: defect = 5.7704e-03 ≈ ε_rms (W-independent ✓)
 W-scan (Nv=0) W=4.0: defect = 5.7704e-03 ≈ ε_rms (W-independent ✓)
 ζ-dictionary DEEP audit (pass 2) — full 50000-zero embedded dataset:
 Z1 monotone (50000 zeros): min Δγ = 0.029538 → OK
 Z2 ±E pairing (D=diag(±γₖ/2), 100000-dim): max|d+d_σ| = 0.0e+00, ‖D+ΓDΓ‖/‖D‖ = 0.00e+00, ‖Γ²v−v‖ = 0.0e+00 → EXACT AIII
 Z3 zero modes of the dictionary: 0 (AIII index anchor; min|γₖ| = 14.1347) → OK
 Z4 ⟨r⟩(49998 raw-gap ratios) = 0.6119 (GUE 0.5996; window ±0.020) vs Poisson control 0.3864 (same n, separation 0.225 > 0.15) → OK (GUE-class, discriminated)
 Z5 block stationarity (5×10k): ⟨r⟩ = 0.6147, 0.6121, 0.6120, 0.6097, 0.6109, spread = 0.0050 < 0.012 → OK
 Z6 KS: D_GUE = 0.021619 (< 0.030), D_GOE = 0.088053 → GUE-class ✓; depth diagnostic: no pass-1 baseline
────────────────────────────────────────────────────────────
 exact row < 1e-10    PASS — binary contract at α=1/2, W=0: 0.00e+00
 ε_rms contract (W=1.0) PASS — defect 5.77e-03 ≈ analytic 2‖ε‖_F/‖H‖_F = 0.0058
 vortices PRESERVE AIII PASS — defect = 0.00e+00 (Nv=2, q=±1.00, W=0) — bond phases; Byers-Yang for integer q
 Coulomb W-scan linear PASS — Nv=2: monotone, defect 0.101→0.746, ratio 7.42 ∈ [5, 12]
 ζ-dict exact ±E pairing PASS — 100k-dim dictionary: max|d+d_σ| = 0.0e+00, ‖D+ΓDΓ‖/‖D‖ = 0.00e+00, Γ² probe 0.0e+00, tower 0
 ζ-50k ⟨r⟩ GUE-window + control PASS — ⟨r⟩ = 0.6119 (GUE 0.5996 ±0.020), Poisson control 0.3864, separation 0.225 > 0.15
 ζ-50k block stationarity PASS — 5×10k blocks spread 0.0050 < 0.012
 ζ-50k KS GUE-class   PASS — D_GUE = 0.0216 < 0.030 and < D_GOE = 0.0881 (Poisson would be ≈0.28)
 Test 27b [HARDCORE pass 2]: 8 sub-checks, 0 failed → PASS
```
