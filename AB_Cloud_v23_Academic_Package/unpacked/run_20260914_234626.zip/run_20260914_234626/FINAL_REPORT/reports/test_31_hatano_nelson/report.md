# Test 31: Hatano-Nelson non-Hermitian skin
Verdict: PASS   |   Generated: 2026-09-15 05:29:51   |   Suite: AB-Cloud v23 SUPERCOMBO (Julia 1.12.0)

## What this test verifies
Deterministic non-Hermitian spectral property: complex eigenvalue count/pattern.
 METHOD: Deterministic non-Hermitian spectral property: complex eigenvalue count/pattern.
Test 31 SERIES: n=5 realizations × σ∈{0.5,0.6,0.7,0.8} @48x48, n_cx mean 0,2225,2281,2295, ⟨r⟩ 0.8953→0.9253, max|Im| 0.3184→0.9576.

## Result
 Test 31c [SERIES pass 3]: 4 sub-checks, 0 failed → PASS

## Plots
- `plots/plot_01.png` — 1600×1000, ABPlotV23 engine (supersampled)
- `plots/plot_02.png` — 1600×1000, ABPlotV23 engine (supersampled)
- `plots/plot_03.png` — 1600×1000, ABPlotV23 engine (supersampled)
- `plots/plot_04.png` — 1600×1000, ABPlotV23 engine (supersampled)
- `plots/animation.gif` — animated reveal of every plot of this test

## Independent verification guide
Reproduce with: julia ab_cloud_v23.jl --test 31 --no-two-pass
Every computation is logged in logs/computation_log.txt (timestamps + deltas); raw console output in logs/stdout_capture.txt.

## FULL COMPUTATION LOG

```text
[05:25:20.846] [+20311.875s]  build_ab_cloud_hamiltonian: 48x48 (N=2304), α=0.5000, t=1.00, W=1.00, torus, 4 vortices, model=:monumental
[05:25:24.130] [+20315.159s]  calc: ⟨r⟩_NN = 0.894102 (n=2304, Poisson-box ref NaN, 10 clouds)
[05:25:39.893] [+20330.922s]  calc: ⟨r⟩_NN = 0.907204 (n=2304, Poisson-box ref 0.851687, 10 clouds)
[05:25:56.656] [+20347.685s]  calc: ⟨r⟩_NN = 0.925299 (n=2304, Poisson-box ref 0.852026, 10 clouds)
[05:26:13.442] [+20364.470s]  calc: ⟨r⟩_NN = 0.930754 (n=2304, Poisson-box ref 0.850043, 10 clouds)
[05:26:14.212] [+20365.240s]  build_ab_cloud_hamiltonian: 48x48 (N=2304), α=0.5000, t=1.00, W=1.00, torus, 4 vortices, model=:monumental
[05:26:17.814] [+20368.842s]  calc: ⟨r⟩_NN = 0.887760 (n=2304, Poisson-box ref NaN, 10 clouds)
[05:26:33.688] [+20384.716s]  calc: ⟨r⟩_NN = 0.910544 (n=2304, Poisson-box ref 0.852173, 10 clouds)
[05:26:50.420] [+20401.449s]  calc: ⟨r⟩_NN = 0.923175 (n=2304, Poisson-box ref 0.852783, 10 clouds)
[05:27:06.833] [+20417.861s]  calc: ⟨r⟩_NN = 0.930952 (n=2304, Poisson-box ref 0.850774, 10 clouds)
[05:27:07.596] [+20418.624s]  build_ab_cloud_hamiltonian: 48x48 (N=2304), α=0.5000, t=1.00, W=1.00, torus, 4 vortices, model=:monumental
[05:27:11.143] [+20422.171s]  calc: ⟨r⟩_NN = 0.898821 (n=2304, Poisson-box ref NaN, 10 clouds)
[05:27:26.749] [+20437.777s]  calc: ⟨r⟩_NN = 0.878783 (n=2304, Poisson-box ref 0.851955, 10 clouds)
[05:27:43.994] [+20455.023s]  calc: ⟨r⟩_NN = 0.888162 (n=2304, Poisson-box ref 0.852427, 10 clouds)
[05:28:01.042] [+20472.071s]  calc: ⟨r⟩_NN = 0.891964 (n=2304, Poisson-box ref 0.850764, 10 clouds)
[05:28:01.794] [+20472.823s]  build_ab_cloud_hamiltonian: 48x48 (N=2304), α=0.5000, t=1.00, W=1.00, torus, 4 vortices, model=:monumental
[05:28:05.354] [+20476.382s]  calc: ⟨r⟩_NN = 0.897703 (n=2304, Poisson-box ref NaN, 10 clouds)
[05:28:21.797] [+20492.826s]  calc: ⟨r⟩_NN = 0.903503 (n=2304, Poisson-box ref 0.851913, 10 clouds)
[05:28:38.374] [+20509.402s]  calc: ⟨r⟩_NN = 0.923336 (n=2304, Poisson-box ref 0.852584, 10 clouds)
[05:28:54.601] [+20525.629s]  calc: ⟨r⟩_NN = 0.935506 (n=2304, Poisson-box ref 0.850682, 10 clouds)
[05:28:55.388] [+20526.416s]  build_ab_cloud_hamiltonian: 48x48 (N=2304), α=0.5000, t=1.00, W=1.00, torus, 4 vortices, model=:monumental
[05:28:58.950] [+20529.978s]  calc: ⟨r⟩_NN = 0.898157 (n=2304, Poisson-box ref NaN, 10 clouds)
[05:29:15.117] [+20546.146s]  calc: ⟨r⟩_NN = 0.906060 (n=2304, Poisson-box ref 0.851688, 10 clouds)
[05:29:32.225] [+20563.253s]  calc: ⟨r⟩_NN = 0.920104 (n=2304, Poisson-box ref 0.851832, 10 clouds)
[05:29:50.149] [+20581.177s]  calc: ⟨r⟩_NN = 0.937177 (n=2304, Poisson-box ref 0.850592, 10 clouds)
```

## CONSOLE CAPTURE

```text

════════════════════════════════════════════════════════════
TEST 31 (pass 3, SERIES): Hatano–Nelson — realization ensemble
────────────────────────────────────────────────────────────
 Ensemble: n=5 realizations × σ ∈ {0.5, 0.6, 0.7, 0.8}, γ = 5.0
 Lattice: 48x48 (N=2304), W_eff = 1.00 (standard), Nv=4 neutral, q=±1.00
 ⚠ RUNTIME: 15 zgeev + 5 heevr rows at 48² ≈ 1–2 min
 real 1/5 σ=0.5: n_complex =     0, max|Im| = 0.0000, ⟨r⟩NN = 0.8941 (2.9 s)
 real 1/5 σ=0.6: n_complex =  2243, max|Im| = 0.3195, ⟨r⟩NN = 0.9072 (15.5 s)
 real 1/5 σ=0.7: n_complex =  2283, max|Im| = 0.6397, ⟨r⟩NN = 0.9253 (16.8 s)
 real 1/5 σ=0.8: n_complex =  2298, max|Im| = 0.9602, ⟨r⟩NN = 0.9308 (16.8 s)
 real 2/5 σ=0.5: n_complex =     0, max|Im| = 0.0000, ⟨r⟩NN = 0.8878 (3.2 s)
 real 2/5 σ=0.6: n_complex =  2237, max|Im| = 0.3194, ⟨r⟩NN = 0.9105 (15.9 s)
 real 2/5 σ=0.7: n_complex =  2297, max|Im| = 0.6396, ⟨r⟩NN = 0.9232 (16.7 s)
 real 2/5 σ=0.8: n_complex =  2299, max|Im| = 0.9598, ⟨r⟩NN = 0.9310 (16.4 s)
 real 3/5 σ=0.5: n_complex =     0, max|Im| = 0.0000, ⟨r⟩NN = 0.8988 (3.1 s)
 real 3/5 σ=0.6: n_complex =  2147, max|Im| = 0.3147, ⟨r⟩NN = 0.8788 (15.6 s)
 real 3/5 σ=0.7: n_complex =  2239, max|Im| = 0.6319, ⟨r⟩NN = 0.8882 (17.2 s)
 real 3/5 σ=0.8: n_complex =  2274, max|Im| = 0.9501, ⟨r⟩NN = 0.8920 (17.0 s)
 real 4/5 σ=0.5: n_complex =     0, max|Im| = 0.0000, ⟨r⟩NN = 0.8977 (3.1 s)
 real 4/5 σ=0.6: n_complex =  2260, max|Im| = 0.3199, ⟨r⟩NN = 0.9035 (16.4 s)
 real 4/5 σ=0.7: n_complex =  2300, max|Im| = 0.6399, ⟨r⟩NN = 0.9233 (16.6 s)
 real 4/5 σ=0.8: n_complex =  2303, max|Im| = 0.9601, ⟨r⟩NN = 0.9355 (16.2 s)
 real 5/5 σ=0.5: n_complex =     0, max|Im| = 0.0000, ⟨r⟩NN = 0.8982 (3.1 s)
 real 5/5 σ=0.6: n_complex =  2237, max|Im| = 0.3183, ⟨r⟩NN = 0.9061 (16.2 s)
 real 5/5 σ=0.7: n_complex =  2287, max|Im| = 0.6381, ⟨r⟩NN = 0.9201 (17.1 s)
 real 5/5 σ=0.8: n_complex =  2303, max|Im| = 0.9578, ⟨r⟩NN = 0.9372 (17.9 s)

 Ensemble means: σ=0.5: n_cx=0.0, max|Im|=0.00e+00, ⟨r⟩=0.8953
 σ=0.8: n_cx=2295.4, max|Im|=0.9576, ⟨r⟩=0.9253 | Poisson-box baseline ≈ 0.8500
 S1 anchor: OK ✓ | S2 sweep: OK ✓ | S3 ⟨r⟩ rise: OK ✓ (0.8953→0.9253) | S4 max|Im| grow: OK ✓ (0.3184→0.9576)
────────────────────────────────────────────────────────────
 σ=0.5 Hermitian ∀real PASS — n_complex = 0 and max|Im| < 1e-10 in all 5 realizations
 n_complex > 0 ∀(σ,k) PASS — every non-Hermitian row (5 × 3) develops complex eigenvalues
 ⟨r⟩ rises with σ (2-D repulsion) PASS — ensemble mean 0.8953 (σ=0.5, line) → 0.9253 (σ=0.8, area)
 max|Im| grows with σ PASS — ensemble mean 0.3184 (σ=0.6) → 0.9576 (σ=0.8), g = (σ−½)·ln|γ|
 Test 31c [SERIES pass 3]: 4 sub-checks, 0 failed → PASS
```
