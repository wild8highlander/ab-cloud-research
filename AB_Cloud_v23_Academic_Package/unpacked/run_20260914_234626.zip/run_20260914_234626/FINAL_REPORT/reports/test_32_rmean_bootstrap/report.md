# Test 32: Multi-realization ⟨r⟩ bootstrap
Verdict: PASS   |   Generated: 2026-09-15 06:47:18   |   Suite: AB-Cloud v23 SUPERCOMBO (Julia 1.12.0)

## What this test verifies
Statistical: ⟨r⟩ = 0.5992 ± 0.022 (tolerance band = monograph §11.1); CI printed as diagnostics. Effective disorder capped: W_eff = min(ab_W, ab_W_max ≤ 1.0) — disorder must not drive the vortex motion.
 METHOD: Statistical: ⟨r⟩ = 0.5992 ± 0.022 (tolerance band = monograph §11.1); CI printed as diagnostics. Effective disorder capped: W_eff = min(ab_W, ab_W_max ≤ 1.0) — disorder must not drive the vortex motion.
Test 32 HARDCORE pass 2: 96x96, n≥5 per row, comparison-row Nv=256 (anchor density), ensemble deep checks (bootstrap CI, scatter, sign count).
 WHY W (DISORDER) IS CAPPED AT W_max ≈ 1.0 — disorder → vortex motion → statistics:
  W is the diagonal on-site potential the vortices paint onto the lattice:
      V_i = Σ_k q_k·W / (r_ik²·N⁻¹ + 1),   hopping t = 1.
  The ratio (disorder energy q·W) / (kinetic energy t) decides what the
  vortex cloud does and which spectral statistics come out:
   • q·W ≳ t  (e.g. W=4, q=0.3 → V≈1.2 next to a core): the disorder
     landscape dominates the vortex motion — vortices pin/steer the
     eigenstates, states localize on the potential relief, and ⟨r⟩ drifts
     from GUE (0.5992) toward Poisson (0.3863) by an essentially random
     amount. A strongly disordered, spinning vortex system can therefore
     emit ALMOST ANY statistics — the numbers depend on the effective
     rotation speed (W/t) and on the twisting/vortex arrangement (Nv,
     layout, charges) of that realization, not on the AB physics.
   • q·W ≲ t  (W ≤ 1): the Aharonov-Bohm phases dominate the hopping,
     states stay delocalized and GUE (Wigner-Dyson) is reachable.
  That is why these tests measure at W_eff = min(cfg.ab_W, W_max = 1.0):
  they certify the PHASE physics, not the disorder physics.
Effective disorder: W_eff = 1.00 = min(ab_W=4.00, ab_W_max=1.00); disorder energy q·W_eff = 1.00 vs hopping t = 1.0
Comparison row q=0.300: W_row=0.50, Nv_row=256 → ⟨r⟩=0.6012 ± 0.0015; nearest class GUE (d_GOE=0.0705, d_GUE=0.0016, d_Poi=0.2149); vortex density 2.78% vs monograph anchor 2.78%.
Test 32 HARDCORE row q=1.000: n=5, bootstrap CI [0.5838, 0.5892] misses GUE; scatter σ=0.0034 (within band).
Test 32 HARDCORE row q=0.300: n=5, bootstrap CI [0.5999, 0.6026] misses GUE; scatter σ=0.0017 (within band).

## Result
 Test 32b [HARDCORE pass 2]: 2 sub-checks, 0 failed → PASS

## Plots
- `plots/plot_01.png` — 1600×1000, ABPlotV23 engine (supersampled)
- `plots/animation.gif` — animated reveal of every plot of this test

## Independent verification guide
Reproduce with: julia ab_cloud_v23.jl --test 32 --no-two-pass
Every computation is logged in logs/computation_log.txt (timestamps + deltas); raw console output in logs/stdout_capture.txt.

## FULL COMPUTATION LOG

```text
[05:37:38.247] [+21049.276s]  realization 1/5 (q=1.000): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[05:37:39.194] [+21050.222s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=1.00, torus, 2 vortices, model=:monumental
[05:43:04.004] [+21375.032s]  calc: ⟨r⟩ = 0.581975 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[05:43:09.335] [+21380.363s]  realization 1/5 (q=1.000): ⟨r⟩=0.5820 in 331.1 s (bulk 5529 levels)
[05:43:09.342] [+21380.371s]  realization 2/5 (q=1.000): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[05:43:10.694] [+21381.722s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=1.00, torus, 2 vortices, model=:monumental
[05:50:47.327] [+21838.355s]  calc: ⟨r⟩ = 0.584950 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[05:50:51.753] [+21842.782s]  realization 2/5 (q=1.000): ⟨r⟩=0.5849 in 462.4 s (bulk 5529 levels)
[05:50:51.761] [+21842.789s]  realization 3/5 (q=1.000): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[05:50:53.212] [+21844.240s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=1.00, torus, 2 vortices, model=:monumental
[05:58:02.624] [+22273.652s]  calc: ⟨r⟩ = 0.588113 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[05:58:06.971] [+22277.999s]  realization 3/5 (q=1.000): ⟨r⟩=0.5881 in 435.2 s (bulk 5529 levels)
[05:58:06.976] [+22278.004s]  realization 4/5 (q=1.000): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[05:58:08.075] [+22279.103s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=1.00, torus, 2 vortices, model=:monumental
[06:04:03.668] [+22634.696s]  calc: ⟨r⟩ = 0.590950 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[06:04:07.951] [+22638.980s]  realization 4/5 (q=1.000): ⟨r⟩=0.5909 in 361.0 s (bulk 5529 levels)
[06:04:07.958] [+22638.986s]  realization 5/5 (q=1.000): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[06:04:08.903] [+22639.931s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=1.00, torus, 2 vortices, model=:monumental
[06:13:24.230] [+23195.258s]  calc: ⟨r⟩ = 0.586224 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[06:13:29.500] [+23200.528s]  realization 5/5 (q=1.000): ⟨r⟩=0.5862 in 561.5 s (bulk 5529 levels)
[06:13:29.535] [+23200.563s]  realization 1/5 (q=0.300): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[06:13:31.169] [+23202.197s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=0.50, open, 256 vortices, model=:monumental
[06:21:33.602] [+23684.630s]  calc: ⟨r⟩ = 0.599252 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[06:21:39.178] [+23690.206s]  realization 1/5 (q=0.300): ⟨r⟩=0.5993 in 489.6 s (bulk 5529 levels)
[06:21:39.192] [+23690.220s]  realization 2/5 (q=0.300): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[06:21:40.830] [+23691.858s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=0.50, open, 256 vortices, model=:monumental
[06:28:58.520] [+24129.548s]  calc: ⟨r⟩ = 0.603718 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[06:29:04.366] [+24135.394s]  realization 2/5 (q=0.300): ⟨r⟩=0.6037 in 445.2 s (bulk 5529 levels)
[06:29:04.377] [+24135.405s]  realization 3/5 (q=0.300): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[06:29:06.001] [+24137.029s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=0.50, open, 256 vortices, model=:monumental
[06:35:18.542] [+24509.570s]  calc: ⟨r⟩ = 0.600059 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[06:35:23.284] [+24514.312s]  realization 3/5 (q=0.300): ⟨r⟩=0.6001 in 378.9 s (bulk 5529 levels)
[06:35:23.295] [+24514.324s]  realization 4/5 (q=0.300): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[06:35:24.690] [+24515.718s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=0.50, open, 256 vortices, model=:monumental
[06:41:23.630] [+24874.658s]  calc: ⟨r⟩ = 0.601791 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[06:41:27.911] [+24878.939s]  realization 4/5 (q=0.300): ⟨r⟩=0.6018 in 364.6 s (bulk 5529 levels)
[06:41:27.915] [+24878.943s]  realization 5/5 (q=0.300): building 96x96 Hamiltonian (large-lattice diag dominates, minutes)
[06:41:29.223] [+24880.251s]  build_ab_cloud_hamiltonian: 96x96 (N=9216), α=0.5000, t=1.00, W=0.50, open, 256 vortices, model=:monumental
[06:47:10.694] [+25221.722s]  calc: ⟨r⟩ = 0.600971 (n_r=5527, n_eigs=5529) [refs: GUE=0.5996 Poisson=0.3863]
[06:47:14.691] [+25225.719s]  realization 5/5 (q=0.300): ⟨r⟩=0.6010 in 346.8 s (bulk 5529 levels)
```

## CONSOLE CAPTURE

```text

════════════════════════════════════════════════════════════
TEST 32 (pass 2, HARDCORE): ⟨r⟩ bootstrap — deep validation
Harder machinery: n ≥ 5 realizations/row, comparison row
held at monograph anchor density on the current lattice, ensemble
stability checks (bootstrap CI, realization scatter, sign count).
────────────────────────────────────────────────────────────
 ⚠ RUNTIME: 2 rows × n=5 realizations at 96x96 → expect ≈ 9–14 min (measured t(L) ≈ 56·(L/96)⁶ s per eig)
 H2: comparison-row Nv rescaled to anchor density 2.78% of 96x96 → Nv=256 (was 144)

════════════════════════════════════════════════════════════
TEST 32: ⟨r⟩ bootstrap over independent realizations
Target: ⟨r⟩ = 0.5992 ± 0.022 vs GUE 0.5992 (machine-precision match)
────────────────────────────────────────────────────────────
 WHY W (DISORDER) IS CAPPED AT W_max ≈ 1.0 — disorder → vortex motion → statistics:
  W is the diagonal on-site potential the vortices paint onto the lattice:
      V_i = Σ_k q_k·W / (r_ik²·N⁻¹ + 1),   hopping t = 1.
  The ratio (disorder energy q·W) / (kinetic energy t) decides what the
  vortex cloud does and which spectral statistics come out:
   • q·W ≳ t  (e.g. W=4, q=0.3 → V≈1.2 next to a core): the disorder
     landscape dominates the vortex motion — vortices pin/steer the
     eigenstates, states localize on the potential relief, and ⟨r⟩ drifts
     from GUE (0.5992) toward Poisson (0.3863) by an essentially random
     amount. A strongly disordered, spinning vortex system can therefore
     emit ALMOST ANY statistics — the numbers depend on the effective
     rotation speed (W/t) and on the twisting/vortex arrangement (Nv,
     layout, charges) of that realization, not on the AB physics.
   • q·W ≲ t  (W ≤ 1): the Aharonov-Bohm phases dominate the hopping,
     states stay delocalized and GUE (Wigner-Dyson) is reachable.
  That is why these tests measure at W_eff = min(cfg.ab_W, W_max = 1.0):
  they certify the PHASE physics, not the disorder physics.
 ℹ️ NOTE: cfg.ab_q_list[1] = 1.0 is INTEGER.
 Pure Dirac-string model: integer flux is unobservable (Byers-Yang)
 → real H → GOE ceiling. The :monumental smooth gauge: phases are
 generically complex for ANY q → GUE reachable with the user's q.
 Primary verdict uses q=1.0; q=0.3 is also run for comparison.

 [q=1.000] Torus gauge-compatible (q·(2-Nx)=-94 ∈ ℤ) → using :torus BC

 Bootstrap config: 96x96, Nv=2, q=±1.000, α=0.5000, W=1.00 (cap 1.00, min(cfg.ab_W, W_max)), BC=:torus, n_real=5
 Disorder check: q·W = 1.00 vs hopping t = 1.0 → AB phases dominate (GUE reachable)
 Vortex phase model: :monumental (complex smooth-gauge phases → GUE reachable for any q)
 NOTE: this is bootstrap row 1/2 — a FULL second set of 5 realizations; the verdict comes from row 1 (the configured q).
 realization 1/5: ⟨r⟩ = 0.5820
 realization 2/5: ⟨r⟩ = 0.5849
 realization 3/5: ⟨r⟩ = 0.5881
 realization 4/5: ⟨r⟩ = 0.5909
 realization 5/5: ⟨r⟩ = 0.5862
 ⟨r⟩ = 0.5864 ± 0.0030 (95% CI [0.5835, 0.5894]) [GUE=0.5996, Pois=0.3863]
 Deviation from GUE 0.5992: -0.0128 (2.13%)
 [q=0.300] Torus not gauge-compatible (q·(2-Nx)=-28.2000 ∉ ℤ) → using :open BC
 [comparison-row overrides] W=0.50 (ab_W_cmp, cap 1.00), Nv=256 (ab_nv_cmp) (primary row: W=1.00, Nv=2)

 Bootstrap config: 96x96, Nv=256, q=±0.300, α=0.5000, W=0.50 (cap 1.00, ab_W_cmp), BC=:open, n_real=5
 Disorder check: q·W = 0.15 vs hopping t = 1.0 → AB phases dominate (GUE reachable)
 Vortex phase model: :monumental (complex smooth-gauge phases → GUE reachable for any q)
 NOTE: this is bootstrap row 2/2 — a FULL second set of 5 realizations; the verdict comes from row 1 (the configured q).
 realization 1/5: ⟨r⟩ = 0.5993
 realization 2/5: ⟨r⟩ = 0.6037
 realization 3/5: ⟨r⟩ = 0.6001
 realization 4/5: ⟨r⟩ = 0.6018
 realization 5/5: ⟨r⟩ = 0.6010
 ⟨r⟩ = 0.6012 ± 0.0015 (95% CI [0.5997, 0.6027]) [GUE=0.5996, Pois=0.3863]
 Deviation from GUE 0.5992: +0.0020 (0.33%)
 Row diagnostics: nearest class = GUE (d_GOE=0.0705, d_GUE=0.0016, d_Poi=0.2149)
 Row diagnostics: vortex density 2.78% (Nv=256 on 96x96) vs monograph anchor 2.78% (25/30×30)
 Row readout: GUE-proximity → the fractional-q row is healthy at this W/Nv.

 ─── Final verdict ───
 Primary result (q=1.000): ⟨r⟩=0.5864 ± 0.0030
 GUE target: 0.5992 ± 0.022
 Poisson: 0.3863
 ─────────────────────
 (comparison) q=0.3 (fractional) gave ⟨r⟩=0.6012 at W=0.50, Nv=256.
 Test 32: ⟨r⟩=0.5864±0.003 (q=1.0, n=5, W=1.0) vs GUE 0.5992 → PASS

 ─── HARDCORE ensemble checks (per row) ───
 q=1.000: n=5, ⟨r⟩=0.5864 ± 0.0015 | bootstrap 95% CI [0.5838, 0.5892] ∌ GUE (diagnostic)
 realization scatter σ=0.0034 ≤ ✓ monograph band 0.022 | above/below GUE: 0/5
 q=0.300: n=5, ⟨r⟩=0.6012 ± 0.0008 | bootstrap 95% CI [0.5999, 0.6026] ∌ GUE (diagnostic)
 realization scatter σ=0.0017 ≤ ✓ monograph band 0.022 | above/below GUE: 5/0
────────────────────────────────────────────────────────────
 row q=1.00 scatter   PASS — σ=0.0034 vs band 0.022 (CI [0.5838, 0.5892] ∌ GUE, 0/5 above/below)
 row q=0.30 scatter   PASS — σ=0.0017 vs band 0.022 (CI [0.5999, 0.6026] ∌ GUE, 5/0 above/below)
 Test 32b [HARDCORE pass 2]: 2 sub-checks, 0 failed → PASS
```
