# Local-compile notes (NSR package)

The reference PDF `manuscript_NSR.pdf` was produced with Tectonic (XeTeX bundle) whose
`fancyhdr` is v4.0.1, while `nsr.cls` expects v4.1. Two one-line patches to the LOCAL
copy only make the class's pagestyle code compile under v4.0.1:

1. `\RequirePackage[T1, T2A]{fontenc}` → `\RequirePackage[T1]{fontenc}`
   (the manuscript is English-only; the original class line is kept in the shipped
   `nsr.cls` for journal-side compilation).
2. The fancyhdr internals `\f@nch@fancyhf` and `\f@nch@rc` were re-defined as
   `\long` macros (body copied verbatim from fancyhdr v4.0.1).

Neither patch changes any layout command of the class. With TeX Live (fancyhdr ≥ 4.1)
the unpatched journal class compiles the manuscript as-is:
    pdflatex manuscript_NSR.tex && pdflatex manuscript_NSR.tex
