# Local-compile notes (NSR package)

The reference PDF `manuscript_NSR.pdf` was produced with Tectonic (XeTeX bundle) whose
`fancyhdr` is v4.0.1, while `nsr.cls` expects v4.1. Two one-line patches to the LOCAL
copy only make the class's pagestyle code compile under v4.0.1:

1. `\RequirePackage[T1, T2A]{fontenc}` → `\RequirePackage[T1]{fontenc}`
   (the manuscript is English-only; the original class line is kept in the shipped
   `nsr.cls` for journal-side compilation).
2. The fancyhdr internals `\f@nch@fancyhf` and `\f@nch@rc` were re-defined as
   `\long` macros (body copied verbatim from fancyhdr v4.0.1).

Neither patch changes any layout command of the class. With TeX Live (fancyhdr ≥ 4.1)
the unpatched journal class compiles the manuscript as-is:
    pdflatex manuscript_NSR.tex && pdflatex manuscript_NSR.tex

## Rebuild verification (2026-10-19 re-seal)

The reference PDF shipped in this package was rebuilt on 19 October 2026 with
the same engine and recipe as the original 8 October 2026 build (Tectonic 0.15.0,
XeTeX bundle, the two local patches documented above applied to a local copy of
`nsr.cls`; the shipped `nsr.cls` remains byte-identical to the journal original).
The rebuild follows the removal of one stale duplicated sentence-pair in the
Appendix B provenance text (the "reproduces the complete source" paragraph,
superseded by the Supplemental-Material paragraph that follows it — see the
Journal shelf CHANGELOG, entry 2026-10-19). The compiled result is 99 pp. in the journal layout — one page short of the
2026-10-08 build (100 pp.), because the removed stale paragraph shortened
the Appendix B flow; the trailing content is unchanged. All checksums in
this package's `SHA256SUMS.txt` were regenerated after the rebuild.
