# Supplemental Material — AB-Cloud v23

This folder accompanies the manuscript and contains every artefact needed to verify the
numbers quoted in the paper, without executing any code.

| Path | What it is |
|---|---|
| `appendix_b_code_full_source_listing.pdf` | Complete 32,095-line Julia source listing (the v3.3 reference build; 220 pp.) |
| `lab_standalone/` | Standalone Julia laboratories: `ab_cloud_v23.jl` (the full 38-test suite, v3.3), `finite-size_lab.jl` (v1.3), `hp_audit_standalone.jl` (HP·MERIDIAN audit module), with READMEs |
| `python_clone/` | Dependency-light Python reimplementation of all 38 tests (CLI, reports, plots; `requirements.txt` + `pyproject.toml` + equivalence-table README) |
| `run_data/run_20260914_234626/` | The reference run: 38 test folders (reports in 4 formats, computation logs, console captures, plots/animations), four-format FINAL_REPORT, consolidated logs, one-line verdict register |
| `run_data/run_20260917_080329_m2/`, `run_data/run_20260917_084900_m3/`, `run_data/run_20260919_085734_m2/` | September 2026 addendum runs behind every number of the final manuscript chapter |
| `run_data/AUDIT_DATA.md` | Reading guide for the audit tier (HARDCORE / SERIES / AUDIT batteries) |

## Reading paths

- *One test's exact numbers:* `run_data/run_20260914_234626/test_XX_<slug>/` — each folder
  carries verdicts, verification statement, computation-log excerpt and console capture.
- *Run the code:* `julia lab_standalone/ab_cloud_v23.jl --help` (Julia 1.12;
  dependency-free), or `python python_clone/abcloud` (minutes on commodity hardware).
- *Archived dataset:* DOI 10.5281/zenodo.21825394 · Code: github.com/wild8highlander/ab-cloud-research

All files are checksummed in the package-level `SHA256SUMS.txt`.
