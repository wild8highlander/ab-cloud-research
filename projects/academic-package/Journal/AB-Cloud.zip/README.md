# AB-Cloud — Journal Submission Deliverables (all-in-one bundle)

Prepared: 8 October 2026 · re-sealed: 19 October 2026 · from the unified academic
edition of [github.com/wild8highlander/ab-cloud-research](https://github.com/wild8highlander/ab-cloud-research)

Author: Isaev Iskhak Khamzatovich (I. K. Isaev) · ORCID 0009-0003-7299-0701 · aslan08_05@mail.ru
Affiliation (with postal address, used in all three packages):
AB-Cloud Research Laboratory, Independent Researcher, Prospekt Lenina 29, Apt. 140,
Nalchik, Kabardino-Balkarian Republic, Russian Federation

## Packages

The three venue zips below are **byte-identical to their shelf copies** in
`AB_Cloud_Academic_Package/Journal/`.

| File | For | Content |
|---|---|---|
| `NSR_JINR_submission_AB-Cloud.zip` | Natural Science Review (JINR), nsr.jinr.int | Full manuscript (99 pp.) on official nsr.cls v1.5, cover letter, 48 figures, supplemental (code + run data), README how-to-submit, SHA256SUMS |
| `SciPost_Physics_submission_AB-Cloud.zip` | SciPost Physics, scipost.org | Publication version (60 pp.) + condensed **Core version (11 pp.)** on official SciPost.cls, cover letter, 48 figures, supplemental, README, SHA256SUMS |
| `arXiv_submission_AB-Cloud.zip` | arXiv.org preprint | Flat package: `main.tex` (standard article class, inline bibliography), `figures/` (48), metadata README, SHA256SUMS; ready to zip-and-upload |

## Preview PDFs (not for upload)

- `NSR_manuscript_preview.pdf` — compiled reference PDF of the NSR manuscript
  (99 pp., journal layout) — **byte-identical to `nsr_submission/manuscript_NSR.pdf`**
  inside the NSR zip (verified, 2026-10-19 re-seal)
- `SciPost_manuscript_preview.pdf` — Publication version — **byte-identical to
  `scipost_submission/scipost_manuscript.pdf`** inside the SciPost zip (verified)
- `SciPost_core_manuscript_preview.pdf` — Core (short) version — **byte-identical to
  `scipost_submission/scipost_core_manuscript.pdf`** inside the SciPost zip (verified)
- `arXiv_manuscript_preview.pdf` — how arXiv will compile `main.tex` (54 pp.;
  the arXiv zip carries no PDF by design)

## Which SciPost version to submit?

Submit **one** of the two. The Publication version is the complete academic account
(60 pp.); the Core version is the condensed communication (11 pp.) for SciPost's
short-format article type — pick Core if you prefer a faster, tighter review.
The same figures/ and supplemental/ serve both.

## Human steps remaining

1. NSR wizard: topic **Physics** (pre-selected in the plan); metadata forms mirror the
   declarations inside the manuscript.
2. SciPost wizard: pick specialties (recommended: Statistical Physics + Mathematical
   Physics) and the article type (**Publication** or **Core**, matching the tex you upload).
3. arXiv: request endorsement for math-ph (first-time submitters), paste the metadata
   from `README_arxiv_metadata.md`, choose the **non-exclusive licence to distribute** —
   arXiv's default and most restrictive option, consistent with the strictly personal
   licence of this repository.

Every package carries its own `README_how_to_submit.md` (or `README_arxiv_metadata.md`)
with the step-by-step wizard guide and requirements checklist. The shelf around these
packages — visible guide copies, folder-level `SHA256SUMS.txt`, the submission status
tracker and the shelf changelog — lives in `AB_Cloud_Academic_Package/Journal/`.
